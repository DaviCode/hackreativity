<?php

class Application_Resource_Segnalazioni_Item extends Zend_Db_Table_Row_Abstract
{

}

