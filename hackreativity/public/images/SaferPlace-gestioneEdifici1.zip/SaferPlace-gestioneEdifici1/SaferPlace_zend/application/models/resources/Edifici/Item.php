<?php

class Application_Resource_Edifici_Item extends Zend_Db_Table_Row_Abstract
{
    public function init()
    {
    }

}