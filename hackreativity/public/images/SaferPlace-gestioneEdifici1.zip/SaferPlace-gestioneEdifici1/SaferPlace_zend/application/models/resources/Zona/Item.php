<?php

class Application_Resource_Zona_Item extends Zend_Db_Table_Row_Abstract
{

}