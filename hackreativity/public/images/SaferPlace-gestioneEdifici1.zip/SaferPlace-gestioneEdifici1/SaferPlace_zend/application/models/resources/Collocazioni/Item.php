<?php

class Application_Resource_Collocazioni_Item extends Zend_Db_Table_Row_Abstract
{

}

