<?php

class Application_Resource_Faq_Item extends Zend_Db_Table_Row_Abstract
{   
	public function init()
    {
    }
    
}
