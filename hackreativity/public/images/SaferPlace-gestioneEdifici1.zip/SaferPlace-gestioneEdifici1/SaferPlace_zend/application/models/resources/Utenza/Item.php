<?php

class Application_Resource_Utenza_Item extends Zend_Db_Table_Row_Abstract
{

}

