<?php

class Application_Resource_Posizioni_Item extends Zend_Db_Table_Row_Abstract
{

}

