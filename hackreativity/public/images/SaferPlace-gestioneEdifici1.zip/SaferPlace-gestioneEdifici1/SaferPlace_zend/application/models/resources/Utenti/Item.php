<?php

class Application_Resource_Utenti_Item extends Zend_Db_Table_Row_Abstract
{

}

