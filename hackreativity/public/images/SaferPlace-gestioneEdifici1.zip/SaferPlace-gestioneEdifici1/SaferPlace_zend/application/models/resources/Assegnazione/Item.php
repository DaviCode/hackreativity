<?php

class Application_Resource_Assegnazione_Item extends Zend_Db_Table_Row_Abstract
{

}

