
$(document).ready(function(){

    $('.modal-trigger').leanModal();
});