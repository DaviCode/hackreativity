
![logo] (https://github.com/NicolaSabino/SaferPlace/blob/master/logolungo.png)
**Applicativo web per la gestione dell' evacuazione del personale da edifici di diversa entità**
>Progetto ideato dal Prof.Cucchiarelli docente del corso di Tecnologie Web dell'Università Politecnico delle Marche

![alt text](https://github.com/NicolaSabino/SaferPlace/blob/master/screen.png)

***
![news](http://www.pasuto.com/img/new30px.png)
Consulta la nostra [wiki](https://github.com/NicolaSabino/SaferPlace/wiki) per ulteriori informazioni sul progetto e il [manuale utente](https://github.com/NicolaSabino/SaferPlace/wiki/Manuale-utente) dell'applicazione


***

Realizzato da

**Nicola Sabino**       nicola.sabino94@gmail.com

**Alessandro Zechini**  zechini.alessandro@gmail.com

**Giulia Traballoni**   giulia0709@hotmail.com

**Giuseppe Romani**     gromani14@gmail.com


***
![alt text](http://www.alsacreations.com/xmedia/doc/full/php-elephant.png) ![alt text](https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/HTML5_logo_and_wordmark.svg/128px-HTML5_logo_and_wordmark.svg.png) ![alt text](http://www.diapason-info.com/wp-content/uploads/2014/07/zend-framework.jpg) ![alt text](http://www.kalmstrom.com/images/logos/Icons/JavaScript128.png) ![alt text](http://3.bp.blogspot.com/-Pv6D2RbhMoY/UfklyE_3fkI/AAAAAAAAAo0/wftYaC95wQg/s1600/logo-jquery2.png) ![alt text](http://materializecss.com/images/favicon/apple-touch-icon-152x152.png)



